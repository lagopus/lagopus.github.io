#!/bin/sh
export RTE_SDK=${HOME}/handson/dpdk-1.7.0
export RTE_TARGET=x86_64-native-linuxapp-gcc

cd $RTE_SDK
sudo make install T=${RTE_TARGET}
cd ..
